package com.cdackolkata;

public interface DBIntializer {
String DRIVER="com.mysql.jdbc.Driver";
String CON_STRING="jdbc:mysql://localhost:3306/test";
String USERNAME="root";
String PASSWORD="root";
}
